import React from "react";
export default function DeletePatient({setPopup}) {
  return (
    <div></div>
  );
}
