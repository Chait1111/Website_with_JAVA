import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Addpatient() {
  let navigate = useNavigate();

  const [patient, setPatient] = useState({
    patientName: "",
    phone_no: "",
    doctorName: "",
    gender: "",
    age: "",
    address: "",
    disease: "",
    insurance: "",
  });

  const {
    patientName,
    phone_no,
    doctorName,
    gender,
    age,
    address,
    disease,
    insurance,
  } = patient;

  const onInputChange = (e) => {
    setPatient({ ...patient, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/addPatient", patient);
    navigate("/");
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Register patient</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="PatientName" className="form-label">
                Patient's Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter patient's name"
                name="patientName"
                value={patientName}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Phone_no" className="form-label">
                Patient's Phone Number
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Patient's Phone Number"
                name="phone_no"
                value={phone_no}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="DoctorName" className="form-label">
                Doctor's Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Doctor's Name"
                name="doctorName"
                value={doctorName}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Gender" className="form-label">
                Patient's Gender
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Patient's Gender"
                name="gender"
                value={gender}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Age" className="form-label">
                Patient's Age
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Patient's Age"
                name="age"
                value={age}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Address" className="form-label">
                Patient's Address
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Patient's Address"
                name="address"
                value={address}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Disease" className="form-label">
                Known Disease
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Known Disease or Symptoms"
                name="disease"
                value={disease}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Insurance" className="form-label">
                Has Insurance
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="if patient have insurance then put true else false"
                name="insurance"
                value={insurance}
                onChange={(e) => onInputChange(e)}
              />
              {/* <br />
              <input type="radio" id="true" name="insurance" value={insurance} />
              <label HTMLFor="true">true</label>
              <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
              <input type="radio" id="false" name="insurance" value={insurance} />
              <label HTMLFor="false">false</label>  */}
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/">
              Cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
