import axios from "axios";
import React, { useEffect,useState } from "react";
import { Link, useParams } from "react-router-dom";

export default function Viewpatient() {
  const [patient, setPatient] = useState({
    id:"",
    patientName: "",
    phone_no: "",
    doctorName: "",
    gender: "",
    age: "",
    address: "",
    disease: "",
    insurance: "",
    date:""
    });
  const [insurance, setInsurance] = useState();
  const { id } = useParams();

  useEffect(() => {
    loadPatient();
  }, []);

  const loadPatient = async () => {
    const result = await axios.get(`http://localhost:8080/getPatientById/${id}`);
    setPatient(result.data);
    console.log(result.data);
    if(result.data.insurance===true){
      setInsurance("Yes");
    }else{
      setInsurance("No");
    }
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Patient's Details</h2>
          <div className="card">
            <div className="card-header">
              Details of patient id : {patient.id}
              <ul className="list-group list-group-flush">
                <li className="list-group-item">
                  <b>Patient's Name:</b>
                  {patient.patientName}
                </li>
                <li className="list-group-item">
                  <b>Patient's Phone Number:</b>
                  {patient.phone_no}
                </li>
                <li className="list-group-item">
                  <b>Doctor's Name:</b>
                  {patient.doctorName}
                </li>
                <li className="list-group-item">
                  <b>Patient's Gender:</b>
                  {patient.gender}
                </li>
                <li className="list-group-item">
                  <b>Patient's Age:</b>
                  {patient.age}
                </li>
                <li className="list-group-item">
                  <b>Patient's Address:</b>
                  {patient.address}
                </li>
                <li className="list-group-item">
                  <b>Patient's Disease:</b>
                  {patient.disease}
                </li>
                <li className="list-group-item">
                  <b>Patient's Insurance:</b>
                  {insurance}
                </li>
                <li className="list-group-item">
                  <b>Appointment Date:</b>
                  {patient.date}
                </li>
              </ul>
            </div>
          </div>
          <Link className="btn btn-primary my-2" to={"/"}>
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
