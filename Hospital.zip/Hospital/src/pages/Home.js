import React, { useEffect, useState } from "react";
import axios from "axios";
import Popup from "reactjs-popup";
import { Link } from "react-router-dom";
export default function Home() {
  const [patients, setPatients] = useState([]);
  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    const result = await axios.get("http://localhost:8080/getAllPatients");
    setPatients(result.data);
  };

  const deletePatient = async (id) => {
    await axios.delete(`http://localhost:8080/deletePatientById/${id}`);
    loadPatients();
  };

  return (
    <div>
      <div className="container">
        <div className="py-4">
          <table className="table border shadow">
            <thead>
              <tr>
                <th scope="col">S.N</th>
                <th scope="col">PatientName</th>
                <th scope="col">DoctorName</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((patient, index) => (
                <tr>
                  <th scope="row" key={index}>
                    {index + 1}
                  </th>
                  <td>{patient.patientName}</td>
                  <td>{patient.doctorName}</td>
                  <td>{patient.date}</td>
                  <td>
                    <Link
                      className="btn btn-info mx-2"
                      to={`/viewpatient/${patient.id}`}
                    >
                      View
                    </Link>
                    <Link
                      className="btn btn-warning mx-2"
                      to={`/editpatient/${patient.id}`}
                    >
                      Edit
                    </Link>
                    {/* <button
                      className="btn btn-danger mx-2"
                      onClick={() => deletePatient(patient.id)}
                    >
                      Delete
                    </button> */}
                    <Popup
                      trigger={
                        <button className="btn btn-danger mx-2"> Delete</button>
                      }
                      position="center"
                    >
                      {close =>(<div className="bg-light p-4 rounded shadow">
                        <h6>Delete Record of {patient.patientName} ?</h6>
                        <button
                          className="btn btn-primary mx-2"
                          onClick={() => {
                            close();
                          }}
                        >
                          Cancel
                        </button>
                        <button
                          className="btn btn-danger mx-2"
                          onClick={() => deletePatient(patient.id)}
                        >
                          Confirm
                        </button>
                      </div>)}
                    </Popup>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
