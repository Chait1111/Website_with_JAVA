import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Navbar from './layout/Navbar';
import Home from './layout/Home';
import Dashboard from './pages/Dashboard';
import {BrowserRouter as Router , Routes , Route } from 'react-router-dom';
import AddUser from './application/AddUser';
import EditUser from './application/EditUser';
import ViewUser from './application/ViewUser';
import Transaction from './pages/Transaction';
import Login from './pages/Login';
import Forget from './pages/Forget';
import AddTransaction from './application/AddTransaction';
import EditTransaction from './application/EditTransaction';
import UserDash from './pages/UserDash';
function App() {
  return (
    <div className="App">
      <Router>
      <Navbar/>
      <Routes>
      <Route exact path = "/" element = {<Home/>}></Route>
        <Route exact path = "/Dashboard" element = {<Dashboard/>}></Route>
        <Route exact path = "/UserDash/:id" element = {<UserDash/>}></Route>
        <Route exact path = "/addUser" element = {<AddUser/>}></Route>
        <Route exact path = "/loginUser" element = {<Login/>}></Route>
        <Route exact path = "/forgetPassword" element = {<Forget/>}></Route>
        <Route exact path = "/editUserById/:id" element = {<EditUser/>}></Route>
        <Route exact path = "/viewUserById/:id" element = {<ViewUser/>}></Route>
        <Route exact path = "/viewTransactionByUser/:id" element = {<Transaction/>}></Route>
        <Route exact path = "/addTransaction/:id" element = {<AddTransaction/>}></Route>
        <Route exact path = "/editTransaction/:transactionId" element = {<EditTransaction/>}></Route>
      </Routes>
      </Router>
    </div>
  );
}

export default App;
