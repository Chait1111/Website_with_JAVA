import React from 'react'
import bankimage from './RY1.jpg';
export default function () {
  return (
    <div>
        <img src={bankimage}/>
    </div>
  )
}
