import React , {useState} from "react";
import { Link } from "react-router-dom";
import banklogo from "./banklogo.png";
export default function Navbar() {
  const [log,setLog] = useState(false);
  if (log===false) {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <div className="container-fluid">
            <a className="navbar-brand" href="/">
              <img src={banklogo} width="100" height="50" />
              Royal Bank
            </a>
            <div>
              <Link className="btn btn-outline-light mx-2" to="/addUser">
                Register
              </Link>
              <Link className="btn btn-outline-light mx-2" to="/loginUser" onClick={()=>setLog(true)}>
                Login
              </Link>
            </div>
          </div>
        </nav>
      </div>
    );
  } else {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <div className="container-fluid">
            <a className="navbar-brand" href="/">
              <img src={banklogo} width="100" height="50" />
              Royal Bank
            </a>
            <div>
              <Link className="btn btn-outline-light mx-2" to="/" onClick={()=>setLog(false)}>
                Logout
              </Link>
            </div>
          </div>
        </nav>
      </div>
    );
  }
}

