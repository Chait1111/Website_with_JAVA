import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
export default function Transaction() {
  const [user, setUser] = useState({
    name: "",
    username: "",
    email: "",
    password: "",
    mobile: "",
    transaction: [
      {
        transactionId: "",
        amount: "",
        operation: "",
        date: "",
      },
    ],
  });

  const [transactions, setTransaction] = useState({
    transactionId: "",
    amount: "",
    operation: "",
    date: "",
  });

  const { id } = useParams();
  // const { transactionId } = useParams();

  useEffect(() => {
    loadUser();
  }, []);
  useEffect(() => {
    loadTransaction();
  }, []);

  const loadTransaction = async () => {
    const result = await axios.get(
      `http://localhost:8080/getTransactionByUser/${id}`
    );
    console.log(result);
    setTransaction(result.data);
  };

  const loadUser = async () => {
    const result = await axios.get(`http://localhost:8080/getUserById/${id}`);
    setUser(result.data);
  };

  const deleteTransaction = async (transactionId) => {
    const result = await axios.delete(
      `http://localhost:8080/deleteTransactionByTransactionId/${transactionId}`
    );
    loadUser();
  };

  return (
    <div className="container">
      <div className="py-4">
        <nav className="navbar navbar-expand-lg navbar-dark bg-info">
          <div className="container-fluid">
            <Link
              className="btn btn-dark mx-2"
              to={`/addTransaction/${user.id}`}
            >
              Add
            </Link>
          </div>
          <Link className="btn btn-danger mx-2" to={-1}>
            Back
          </Link>
        </nav>
        <table className="table shadow">
          <thead>
            <tr>
              <th scope="col">TransactionId</th>
              <th scope="col">Amount</th>
              <th scope="col">Operation</th>
              <th scope="col">Date</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {user.transaction.map((transaction) => (
              <tr>
                <th>{transaction.transactionId}</th>
                <td>{transaction.amount}</td>
                <td>{transaction.operation}</td>
                <td>{transaction.date}</td>
                <td>
                  <Link
                    className="btn btn-warning mx-2"
                    to={`/editTransaction/${transaction.transactionId}`}
                  >
                    Edit
                  </Link>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteTransaction(transaction.transactionId)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
