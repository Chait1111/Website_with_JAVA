import React from "react";
import { Link, useParams } from "react-router-dom";
export default function UserDash() {
  const { id } = useParams();
  return (
    <div className="p-5">
      <Link className="btn btn-dark mx-2" to={`/viewUserById/${id}`}>
        View
      </Link>
      <Link className="btn btn-warning mx-2" to={`/editUserById/${id}`}>
        Edit
      </Link>

      <Link
        className="btn btn-info mx-2"
        to={`/viewTransactionByUser/${id}`}
      >
        Transactions
      </Link>
    </div>
  );
}
