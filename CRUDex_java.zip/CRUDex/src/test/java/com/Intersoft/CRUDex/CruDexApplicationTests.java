package com.Intersoft.CRUDex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruDexApplicationTests {

	@Test
	void contextLoads() {
	}

}
