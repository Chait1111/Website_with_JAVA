package com.Intersoft.CRUDex.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Intersoft.CRUDex.entity.Product;
import com.Intersoft.CRUDex.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository repository;
	@Autowired
    private SessionFactory sessionFactory;
	protected Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }
	public void saveProduct(Product product) {
		getCurrentSession().save(product);
	}
	public List<Product> saveProducts(List<Product> products) {
		return repository.saveAll(products);
	}
	public List<Product> getProducts() {
		return repository.findAll();
	}
	public Product getProductById(int id) {
		return repository.findById(id).orElse(null);
	}
	public Product getProductByName(String name) {
		return repository.findByName(name);
	}
	public String deleteProduct(int id) {
		repository.deleteById(id);
		return "Product removed with "+id;
	}
	public Product updateProduct(Product product) {
		Product existingProduct=repository.findById(product.getId()).orElse(null);
		existingProduct.setName(product.getName());
		existingProduct.setQuantity(product.getQuantity());
		existingProduct.setPrice(product.getPrice());
		return repository.save(existingProduct);
	}
	public List<Product> getProductByNameContaining(String name){
		return repository.findByNameContaining(name);
	}
	public List<Product> getProductWithHighQuantity(int num) {
		return repository.moreQuantity(num);
	}
	public void updateProductQuantityPath(int id, int quantity) {
		 repository.updateQuantityPath(id,quantity);
	}
	public void updateProductQuantityBody(Product product) {
		int id = product.getId();
		int quantity = product.getQuantity();
		repository.updateQuantityBody(id,quantity);
	}
}
