package com.Intersoft.CRUDex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@SpringBootApplication
public class CruDexApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruDexApplication.class, args);
	}

}
