package com.Intersoft.CRUDex.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.core.env.Environment;
import com.Intersoft.CRUDex.entity.Product;
import com.Intersoft.CRUDex.service.ProductService;

@RestController
public class ProductController {
	//---------------------------------------------------------------------------------
	@Autowired
	private Environment environment;
	 @GetMapping("/api/proporties")
	    public HashMap showProporties(){      
	        HashMap hmap = new HashMap();
			hmap.put("username",environment.getProperty("spring.datasource.username"));
//			hmap.put("password",environment.getProperty("spring.datasource.password"));
			hmap.put("source.url",environment.getProperty("spring.datasource.url"));
			hmap.put("server.port",environment.getProperty("server.port"));
	        return hmap;
	    }
	 //--------------------------------------------------------------------------------

	 //--------------------------------------------------------------------------------
	@Autowired
	private ProductService service;
	@PostMapping("/addProduct")
	public void addProduct(@RequestBody Product product) {
		service.saveProduct(product);
	}
	@PostMapping("/addProducts")
	public List<Product> addProducts(@RequestBody List<Product> products) {
        return service.saveProducts(products);
    }
	@GetMapping("/products")
    public List<Product> findAllProducts() {
        return service.getProducts();
    }
    @GetMapping("/productById/{id}")
    public Product findProductById(@PathVariable int id) {
        return service.getProductById(id);
    }
    @GetMapping("/product/{name}")
    public Product findProductByName(@PathVariable String name) {
        return service.getProductByName(name);
    }
    @GetMapping("/Login/{name}")
    public void LoginByName(@PathVariable String name) {
    	int pass=20800;
        Product user = service.getProductByName(name);
        if(user.getPrice()==pass)
        	System.out.println("success");
        else
        	System.out.println("failed");
    }
    @PutMapping("/update")
    public Product updateProduct(@RequestBody Product product) {
        return service.updateProduct(product);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int id) {
        return service.deleteProduct(id);
    }
    @GetMapping("/productContaining/{name}")
    public List<Product> findProductByNameContaining(@PathVariable String name) {
        return service.getProductByNameContaining(name);
    }
    @GetMapping("/Quantity/{num}")
    public List<Product> highQuantity(@PathVariable int num) {
        return service.getProductWithHighQuantity(num);
    }
    @PutMapping("/updateQuantity/{id}/{quantity}")
    public void updateQuantityPath(@PathVariable int id,@PathVariable int quantity) {
    	service.updateProductQuantityPath(id,quantity);
    }
    @PutMapping("/updateQuantity")
    public void updateQuantityBody(@RequestBody Product product) {
    	service.updateProductQuantityBody(product);
    }
}
