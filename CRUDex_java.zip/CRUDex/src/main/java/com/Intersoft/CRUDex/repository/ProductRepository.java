package com.Intersoft.CRUDex.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Intersoft.CRUDex.entity.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product,Integer>{
	Product findByName(String name);
	List<Product> findByNameContaining(String name);
//	@Query("select p from Product p where p.quantity>?1")
//	List<Product> moreQuantity(int num);
	@Query("select p from Product p where p.quantity>:num")
	List<Product> moreQuantity(@Param("num") int num);
	@Modifying
	@Transactional
	@Query("update Product p set p.quantity = ?2 where p.id = ?1")
	void updateQuantityPath(int id, int quantity);
	@Modifying
	@Transactional
	@Query("update Product p set p.quantity =:quantity where p.id =:id")
	void updateQuantityBody(@Param("id")int id,@Param("quantity") int quantity);
	
}
