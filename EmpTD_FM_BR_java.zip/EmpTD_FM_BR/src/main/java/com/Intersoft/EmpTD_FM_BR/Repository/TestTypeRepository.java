package com.Intersoft.EmpTD_FM_BR.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.Intersoft.EmpTD_FM_BR.Entity.TestType;
@Repository
public interface TestTypeRepository extends JpaRepository<TestType,Integer>{

}
