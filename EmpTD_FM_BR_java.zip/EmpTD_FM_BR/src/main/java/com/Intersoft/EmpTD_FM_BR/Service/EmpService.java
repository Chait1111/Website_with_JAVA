package com.Intersoft.EmpTD_FM_BR.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.Intersoft.EmpTD_FM_BR.Entity.Employee;
import com.Intersoft.EmpTD_FM_BR.Entity.EmployeeTestDemand;
import com.Intersoft.EmpTD_FM_BR.Entity.RestrictionType;
import com.Intersoft.EmpTD_FM_BR.Entity.TestType;
import com.Intersoft.EmpTD_FM_BR.Repository.EmployeeRepository;
import com.Intersoft.EmpTD_FM_BR.Repository.EmployeeTestDemandRepository;
import com.Intersoft.EmpTD_FM_BR.Repository.RestrictionTypeRepository;
import com.Intersoft.EmpTD_FM_BR.Repository.TestTypeRepository;
@Service
public class EmpService {
	@Autowired
	EmployeeRepository empRepository;
	
	@Autowired
	TestTypeRepository testRepository;
	
	@Autowired
	RestrictionTypeRepository restrictionRepository;
	
	@Autowired 
	EmployeeTestDemandRepository empTestRepository;
	
	public Employee addEmployee(Employee emp) {
		return empRepository.save(emp);
	}

	public List<Employee> getEmployeeListByFirstName() {
		return empRepository.findAll(Sort.by(Sort.Direction.ASC,"firstName"));
	}
	
	public List<Employee> getEmployeeListByLastName() {
		return empRepository.findAll(Sort.by(Sort.Direction.ASC,"lastName"));
	}

	public TestType addTestType(TestType test) {
		return testRepository.save(test);
	}

	public List<TestType> getTestTypeList() {
		return testRepository.findAll();
	}

	public RestrictionType addRestrictionType(RestrictionType restriction) {
		return restrictionRepository.save(restriction);
	}

	public List<RestrictionType> getRestrictionTypeList() {
		return restrictionRepository.findAll();
	}

	public EmployeeTestDemand addEmployeeTestDemand(EmployeeTestDemand empTD, int emp_id, int test_type_id, int restriction_id) {
		Employee emp = empRepository.findById(emp_id).orElse(null);
		TestType test = testRepository.findById(test_type_id).orElse(null);
		RestrictionType restrict = restrictionRepository.findById(restriction_id).orElse(null);
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		empTD.setDate_entered(date);
		empTD.setEmployee_id(emp);
		empTD.setTest_type_id(test);
		empTD.setRestriction_id(restrict);
		return empTestRepository.save(empTD);
	}

	public List<EmployeeTestDemand> getEmployeeTestDemandList() {
		return empTestRepository.findAll();
	}

	public Employee getEmployeeById(int emp_id) {
		return empRepository.findById(emp_id).orElse(null);
	}

	public TestType getTestTypeById(int test_type_id) {
		return testRepository.findById(test_type_id).orElse(null);
	}

	public RestrictionType getRestrictionTypeById(int restriction_id) {
		return restrictionRepository.findById(restriction_id).orElse(null);
	}

	public EmployeeTestDemand addEmployeeTestDemand(EmployeeTestDemand empTD, int emp_id, int test_type_id) {
		Employee emp = empRepository.findById(emp_id).orElse(null);
		TestType test = testRepository.findById(test_type_id).orElse(null);
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		empTD.setDate_entered(date);
		empTD.setEmployee_id(emp);
		empTD.setTest_type_id(test);
		return empTestRepository.save(empTD);
	}

	public List<EmployeeTestDemand> getEmployeeTestDemandByEmployee(int emp_id) {
		return empTestRepository.findAllEmployeeTestDemandByEmployee(emp_id);
	}

	public EmployeeTestDemand modifyEmployeeTestDemand(EmployeeTestDemand empTD, Long emp_test_id,
			int test_type_id, int restriction_id) {
		EmployeeTestDemand emptd = empTestRepository.findById(emp_test_id).orElse(null);
		TestType test = testRepository.findById(test_type_id).orElse(null);
		RestrictionType restrict = restrictionRepository.findById(restriction_id).orElse(null);
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		emptd.setDate_modified(date);
		emptd.setTest_type_id(test);
		emptd.setRestriction_id(restrict);
		emptd.setRestriction_end_date(empTD.getRestriction_end_date());
		emptd.setTest_date(empTD.getTest_date());
		emptd.setTest_time(empTD.getTest_time());
		emptd.setTest_restricted_hrs_day(empTD.getTest_restricted_hrs_day());
		emptd.setTest_restricted_hrs_week(empTD.getTest_restricted_hrs_week());
		emptd.setTest_shift_hrs_day(empTD.getTest_shift_hrs_day());
		emptd.setTest_shift_hrs_week(empTD.getTest_shift_hrs_week());
		return empTestRepository.save(emptd);
	}

	public EmployeeTestDemand modifyEmployeeTestDemand(EmployeeTestDemand empTD, Long emp_test_id,int test_type_id) {
		EmployeeTestDemand emptd = empTestRepository.findById(emp_test_id).orElse(null);
		TestType test = testRepository.findById(test_type_id).orElse(null);
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		emptd.setDate_modified(date);
		emptd.setRestriction_id(null);
		emptd.setTest_type_id(test);
		emptd.setRestriction_end_date(empTD.getRestriction_end_date());
		emptd.setTest_date(empTD.getTest_date());
		emptd.setTest_time(empTD.getTest_time());
		emptd.setTest_restricted_hrs_day(empTD.getTest_restricted_hrs_day());
		emptd.setTest_restricted_hrs_week(empTD.getTest_restricted_hrs_week());
		emptd.setTest_shift_hrs_day(empTD.getTest_shift_hrs_day());
		emptd.setTest_shift_hrs_week(empTD.getTest_shift_hrs_week());
		return empTestRepository.save(emptd);
	}

	public EmployeeTestDemand deleteEmployeeTestDemand(Long emp_test_id) {
		EmployeeTestDemand emptd = empTestRepository.findById(emp_test_id).orElse(null);
		emptd.setIs_deleted(true);
		return empTestRepository.save(emptd);
	}

	public EmployeeTestDemand getEmployeeTestDemandByEmployeeTestId(Long emp_test_id) {
		return empTestRepository.findById(emp_test_id).orElse(null);
	}

	public EmployeeTestDemand deleteEmployeeTestDemandByEmployeeTestId(Long emp_test_id) {
		EmployeeTestDemand etd = empTestRepository.findById(emp_test_id).orElse(null);
		etd.setIs_deleted(true);
		return empTestRepository.save(etd);
	}

}
