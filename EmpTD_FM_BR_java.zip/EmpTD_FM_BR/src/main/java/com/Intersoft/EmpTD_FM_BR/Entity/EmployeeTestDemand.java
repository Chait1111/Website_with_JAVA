package com.Intersoft.EmpTD_FM_BR.Entity;
import java.sql.Date;
import java.sql.Time;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class EmployeeTestDemand {
	@Id
	@GeneratedValue
	private Long emp_test_id;
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "test_type_id", referencedColumnName = "test_id")
    private TestType test_type_id;
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "restriction_id", referencedColumnName = "rest_id")
    private RestrictionType restriction_id;
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "employee_id", referencedColumnName = "emp_id")
	private Employee employee_id;
	private boolean is_deleted;
	private int test_shift_hrs_day;
	private int test_shift_hrs_week;
	private int test_restricted_hrs_day;
	private int test_restricted_hrs_week;
	private Date test_date;
	private Time test_time;
	private Date restriction_end_date;
	private Date date_entered;
	private Date date_modified;
	public EmployeeTestDemand() {
		super();
	}
	public EmployeeTestDemand(Long emp_test_id, TestType test_type_id, RestrictionType restriction_id,
			Employee employee_id, boolean is_deleted, int test_shift_hrs_day, int test_shift_hrs_week,
			int test_restricted_hrs_day, int test_restricted_hrs_week, Date test_date, Time test_time,
			Date restriction_end_date, Date date_entered, Date date_modified) {
		super();
		this.emp_test_id = emp_test_id;
		this.test_type_id = test_type_id;
		this.restriction_id = restriction_id;
		this.employee_id = employee_id;
		this.is_deleted = is_deleted;
		this.test_shift_hrs_day = test_shift_hrs_day;
		this.test_shift_hrs_week = test_shift_hrs_week;
		this.test_restricted_hrs_day = test_restricted_hrs_day;
		this.test_restricted_hrs_week = test_restricted_hrs_week;
		this.test_date = test_date;
		this.test_time = test_time;
		this.restriction_end_date = restriction_end_date;
		this.date_entered = date_entered;
		this.date_modified = date_modified;
	}
	public TestType getTest_type_id() {
		return test_type_id;
	}
	public void setTest_type_id(TestType test_type_id) {
		this.test_type_id = test_type_id;
	}
	public RestrictionType getRestriction_id() {
		return restriction_id;
	}
	public void setRestriction_id(RestrictionType restriction_id) {
		this.restriction_id = restriction_id;
	}
	public Employee getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(Employee employee_id) {
		this.employee_id = employee_id;
	}
	public Long getEmp_test_id() {
		return emp_test_id;
	}
	public void setEmp_test_id(Long emp_test_id) {
		this.emp_test_id = emp_test_id;
	}
	public boolean isIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(boolean is_deleted) {
		this.is_deleted = is_deleted;
	}
	public int getTest_shift_hrs_day() {
		return test_shift_hrs_day;
	}
	public void setTest_shift_hrs_day(int test_shift_hrs_day) {
		this.test_shift_hrs_day = test_shift_hrs_day;
	}
	public int getTest_shift_hrs_week() {
		return test_shift_hrs_week;
	}
	public void setTest_shift_hrs_week(int test_shift_hrs_week) {
		this.test_shift_hrs_week = test_shift_hrs_week;
	}
	public int getTest_restricted_hrs_day() {
		return test_restricted_hrs_day;
	}
	public void setTest_restricted_hrs_day(int test_restricted_hrs_day) {
		this.test_restricted_hrs_day = test_restricted_hrs_day;
	}
	public int getTest_restricted_hrs_week() {
		return test_restricted_hrs_week;
	}
	public void setTest_restricted_hrs_week(int test_restricted_hrs_week) {
		this.test_restricted_hrs_week = test_restricted_hrs_week;
	}
	public Date getTest_date() {
		return test_date;
	}
	public void setTest_date(Date test_date) {
		this.test_date = test_date;
	}
	public Time getTest_time() {
		return test_time;
	}
	public void setTest_time(Time test_time) {
		this.test_time = test_time;
	}
	public Date getRestriction_end_date() {
		return restriction_end_date;
	}
	public void setRestriction_end_date(Date restriction_end_date) {
		this.restriction_end_date = restriction_end_date;
	}
	public Date getDate_entered() {
		return date_entered;
	}
	public void setDate_entered(Date date_entered) {
		this.date_entered = date_entered;
	}
	public Date getDate_modified() {
		return date_modified;
	}
	public void setDate_modified(Date date_modified) {
		this.date_modified = date_modified;
	}
}
