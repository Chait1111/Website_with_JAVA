package com.Intersoft.EmpTD_FM_BR.Entity;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class RestrictionType {
	@Id
	private int rest_id;
	private String restriction_type;
	@JsonIgnore
    @OneToMany(mappedBy = "restriction_id")
    private List<EmployeeTestDemand> employeeTestDemands;
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "test_rest_id", referencedColumnName = "test_id")
    private TestType test_rest_id;
	private boolean is_deleted;
	public RestrictionType() {
		super();
	}
	public RestrictionType(int rest_id, String restriction_type, List<EmployeeTestDemand> employeeTestDemands,
			TestType test_rest_id, boolean is_deleted) {
		super();
		this.rest_id = rest_id;
		this.restriction_type = restriction_type;
		this.employeeTestDemands = employeeTestDemands;
		this.test_rest_id = test_rest_id;
		this.is_deleted = is_deleted;
	}
	public List<EmployeeTestDemand> getEmployeeTestDemands() {
		return employeeTestDemands;
	}
	public void setEmployeeTestDemands(List<EmployeeTestDemand> employeeTestDemands) {
		this.employeeTestDemands = employeeTestDemands;
	}
	public boolean isIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(boolean is_deleted) {
		this.is_deleted = is_deleted;
	}
	public int getRest_id() {
		return rest_id;
	}
	public void setRest_id(int rest_id) {
		this.rest_id = rest_id;
	}
	public TestType getTest_rest_id() {
		return test_rest_id;
	}
	public void setTest_rest_id(TestType test_rest_id) {
		this.test_rest_id = test_rest_id;
	}
	public String getRestriction_type() {
		return restriction_type;
	}
	public void setRestriction_type(String restriction_type) {
		this.restriction_type = restriction_type;
	}
}
