package com.Intersoft.EmpTD_FM_BR.Entity;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class TestType {
	@Id
	private int test_id;
	private String test_type;
	@JsonIgnore
    @OneToMany(mappedBy = "test_rest_id")
    private List<RestrictionType> restriction_type;
	@JsonIgnore
    @OneToMany(mappedBy = "test_type_id")
    private List<EmployeeTestDemand> employeeTestDemands;
	private boolean is_deleted;
	public TestType() {
		super();
	}
	public TestType(int test_id, String test_type, List<RestrictionType> restriction_type,
			List<EmployeeTestDemand> employeeTestDemands, boolean is_deleted) {
		super();
		this.test_id = test_id;
		this.test_type = test_type;
		this.restriction_type = restriction_type;
		this.employeeTestDemands = employeeTestDemands;
		this.is_deleted = is_deleted;
	}
	public List<EmployeeTestDemand> getEmployeeTestDemands() {
		return employeeTestDemands;
	}
	public void setEmployeeTestDemands(List<EmployeeTestDemand> employeeTestDemands) {
		this.employeeTestDemands = employeeTestDemands;
	}
	public int getTest_id() {
		return test_id;
	}
	public void setTest_id(int test_id) {
		this.test_id = test_id;
	}
	public List<RestrictionType> getRestriction_type() {
		return restriction_type;
	}
	public void setRestriction_type(List<RestrictionType> restriction_type) {
		this.restriction_type = restriction_type;
	}
	public boolean isIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(boolean is_deleted) {
		this.is_deleted = is_deleted;
	}
	public String getTest_type() {
		return test_type;
	}
	public void setTest_type(String test_type) {
		this.test_type = test_type;
	}
}
