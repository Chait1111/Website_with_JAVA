package com.Intersoft.EmpTD_FM_BR.Controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.Intersoft.EmpTD_FM_BR.Entity.Employee;
import com.Intersoft.EmpTD_FM_BR.Entity.EmployeeTestDemand;
import com.Intersoft.EmpTD_FM_BR.Entity.RestrictionType;
import com.Intersoft.EmpTD_FM_BR.Entity.TestType;
import com.Intersoft.EmpTD_FM_BR.Service.EmpService;
@RestController
@CrossOrigin("http://localhost:3000/")
public class EmpController {
	@Autowired
	EmpService service;
	
	@PostMapping("/addEmployee")
	private Employee addEmployee(@RequestBody Employee emp) {
		return service.addEmployee(emp);
	}
	
	@GetMapping("/getEmployeeListByFirstName")
	private List<Employee> getEmployeeListByFirstName(){
		return service.getEmployeeListByFirstName();
	}
	
	@GetMapping("/getEmployeeListByLastName")
	private List<Employee> getEmployeeListByLastName(){
		return service.getEmployeeListByLastName();
	}
	
	@GetMapping("/getEmployeeById/{emp_id}")
	private Employee getEmployeeById(@PathVariable int emp_id){
		return service.getEmployeeById(emp_id);
	}
	
	@PostMapping("/addTestType")
	private TestType addTestType(@RequestBody TestType test) {
		return service.addTestType(test);
	}
	
	@GetMapping("/getTestTypeList")
	private List<TestType> getTestTypeList(){
		return service.getTestTypeList();
	}
	
	@GetMapping("/getTestTypeById/{test_id}")
	private TestType getTestTypeById(@PathVariable int test_id){
		return service.getTestTypeById(test_id);
	}
	
	@PostMapping("/addRestrictionType")
	private RestrictionType addRestrictionType(@RequestBody RestrictionType restriction) {
		return service.addRestrictionType(restriction);
	}
	
	@GetMapping("/getRestrictionTypeList")
	private List<RestrictionType> getRestrictionTypeList(){
		return service.getRestrictionTypeList();
	}
	
	@GetMapping("/getRestrictionTypeById/{rest_id}")
	private RestrictionType getRestrictionTypeById(@PathVariable int rest_id){
		return service.getRestrictionTypeById(rest_id);
	}
	
	@PostMapping("/addEmployeeTestDemand/{emp_id}/{test_type_id}/{restriction_id}")
	private EmployeeTestDemand addEmployeeTestDemand(@RequestBody EmployeeTestDemand empTD,
			@PathVariable int emp_id,@PathVariable int test_type_id,@PathVariable int restriction_id) {
		return service.addEmployeeTestDemand(empTD,emp_id,test_type_id,restriction_id);
	}
	
	@PutMapping("/modifyEmployeeTestDemand/{emp_test_id}/{test_type_id}/{restriction_id}")
	private EmployeeTestDemand modifyEmployeeTestDemand(@RequestBody EmployeeTestDemand empTD,
			@PathVariable Long emp_test_id,@PathVariable int test_type_id,@PathVariable int restriction_id) {
		return service.modifyEmployeeTestDemand(empTD,emp_test_id,test_type_id,restriction_id);
	}
	
	@PutMapping("/modifyEmployeeTestDemand/{emp_test_id}/{test_type_id}")
	private EmployeeTestDemand modifyEmployeeTestDemand(@RequestBody EmployeeTestDemand empTD,
			@PathVariable Long emp_test_id,@PathVariable int test_type_id) {
		return service.modifyEmployeeTestDemand(empTD,emp_test_id,test_type_id);
	}
	
	@PutMapping("/deleteEmployeeTestDemand/{emp_test_id}")
	private EmployeeTestDemand deleteEmployeeTestDemand(@PathVariable Long emp_test_id) {
		return service.deleteEmployeeTestDemand(emp_test_id);
	}
	
	@PostMapping("/addEmployeeTestDemand/{emp_id}/{test_type_id}")
	private EmployeeTestDemand addEmployeeTestDemand(@RequestBody EmployeeTestDemand empTD,
			@PathVariable int emp_id,@PathVariable int test_type_id) {
		return service.addEmployeeTestDemand(empTD,emp_id,test_type_id);
	}
	
	@GetMapping("/getEmployeeTestDemandByEmployee/{emp_id}")
	private List<EmployeeTestDemand> getEmployeeTestDemandByEmployee(@PathVariable int emp_id){
		return service.getEmployeeTestDemandByEmployee(emp_id);
	}
	
	@GetMapping("/getEmployeeTestDemandList")
	private List<EmployeeTestDemand> getEmployeeTestDemandList(){
		return service.getEmployeeTestDemandList();
	}
	
	@GetMapping("/getEmployeeTestDemandByEmployeeTestId/{emp_test_id}")
	private EmployeeTestDemand getEmployeeTestDemandByEmployeeTestId(@PathVariable Long emp_test_id){
		return service.getEmployeeTestDemandByEmployeeTestId(emp_test_id);
	}
	
	@PutMapping("/deleteEmployeeTestDemandByEmployeeTestId/{emp_test_id}")
	private EmployeeTestDemand deleteEmployeeTestDemandByEmployeeTestId(@PathVariable Long emp_test_id){
		return service.deleteEmployeeTestDemandByEmployeeTestId(emp_test_id);
	}
	
}
