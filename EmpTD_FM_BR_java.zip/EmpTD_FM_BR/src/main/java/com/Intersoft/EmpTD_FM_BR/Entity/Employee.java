package com.Intersoft.EmpTD_FM_BR.Entity;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int emp_id;
	@JsonIgnore
    @OneToMany(mappedBy = "employee_id")
    private List<EmployeeTestDemand> employeeTestDemand;
	private String firstName;
	private String lastName;
	private boolean is_deleted;
	public boolean isIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(boolean is_deleted) {
		this.is_deleted = is_deleted;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public List<EmployeeTestDemand> getEmployeeTestDemand() {
		return employeeTestDemand;
	}
	public void setEmployeeTestDemand(List<EmployeeTestDemand> employeeTestDemand) {
		this.employeeTestDemand = employeeTestDemand;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Employee(int emp_id, List<EmployeeTestDemand> employeeTestDemand, String firstName, String lastName,
			boolean is_deleted) {
		super();
		this.emp_id = emp_id;
		this.employeeTestDemand = employeeTestDemand;
		this.firstName = firstName;
		this.lastName = lastName;
		this.is_deleted = is_deleted;
	}
	public Employee() {
		super();
	} 
}
