package com.Intersoft.EmpTD_FM_BR.Repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.Intersoft.EmpTD_FM_BR.Entity.EmployeeTestDemand;
@Repository
public interface EmployeeTestDemandRepository extends JpaRepository<EmployeeTestDemand,Long>{

	@Query(value = "SELECT * FROM employee_test_demand etd where etd.employee_id=:id",
			nativeQuery = true)
	List<EmployeeTestDemand> findAllEmployeeTestDemandByEmployee(@Param("id")int emp_id);

}
