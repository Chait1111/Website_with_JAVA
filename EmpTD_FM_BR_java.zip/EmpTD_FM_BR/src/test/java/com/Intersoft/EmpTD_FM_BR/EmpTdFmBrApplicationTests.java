package com.Intersoft.EmpTD_FM_BR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpTdFmBrApplicationTests {

	@Test
	void contextLoads() {
	}

}
