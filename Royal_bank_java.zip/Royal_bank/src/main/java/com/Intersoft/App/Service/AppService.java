package com.Intersoft.App.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Intersoft.App.Entity.User;
import com.Intersoft.App.Exception.UserNotFoundException;
import com.Intersoft.App.Repository.UserRepository;

@Service
public class AppService {
	@Autowired
	UserRepository repository;

	public User addUserService(User user) {
		return repository.save(user);
	}

	public List<User> getAllUsers() {
		return repository.findAll();
	}

	public User getByUsername(String username) {
		return repository.findByUsername(username).orElseThrow(()->new UserNotFoundException(username));
	}

	public User getUserById(Long id) {
		return repository.findById(id).orElseThrow(()->new UserNotFoundException(id));
	}

	public User editUserById(Long id, User newuser) {
		return repository.findById(id).map(user -> {
			user.setUsername(newuser.getUsername());
			user.setName(newuser.getName());
			user.setEmail(newuser.getEmail());
			user.setPassword(newuser.getPassword());
			user.setMobile(newuser.getMobile());
			return repository.save(user);
		}).orElseThrow(()->new UserNotFoundException(id));
	}

	
	
	public String deleteUserById(Long id) {
		 if(!repository.existsById(id)) {
			 throw new UserNotFoundException(id);
		 }
		 repository.deleteById(id);
		 return "User with "+id+" has been deleted";
	}

	public User changePassword(String username, String Mobile,String newPass) {
		User user = repository.getByUsername(username);
		if(user==null)
		{
			return repository.findByUsername(username).orElseThrow(()->new UserNotFoundException(username));
		}
		else
		{
			if(Mobile.equals(user.getMobile())) {
				user.setPassword(newPass);
				return repository.save(user);
			}
			else
				return repository.findByMobile(Mobile).orElseThrow(()->new UserNotFoundException(username,Mobile));
		}
	}

	public User Login(String username, String password) {
		return repository.findByUsernameAndPassword(username,password).orElseThrow(()->new UserNotFoundException(username,password,1));
	}
}
