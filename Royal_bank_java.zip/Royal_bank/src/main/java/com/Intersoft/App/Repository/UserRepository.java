package com.Intersoft.App.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Intersoft.App.Dto.TransactionResponse;
import com.Intersoft.App.Entity.User;
@Repository
public interface UserRepository extends JpaRepository<User,Long>{

	public User getByUsername(String username);

	public String deleteUserById(Long id);

	public boolean existsByUsername(String username);

	public Optional<User> findByUsername(String username);

	public Optional<User> findByMobile(String mobile);

	public Optional<User> findByUsernameAndPassword(String username, String password);

	public User findUserById(Long id);

	@Query("SELECT new com.Intersoft.App.Dto.TransactionResponse(t.transactionId, t.amount, t.operation, t.date) FROM User u JOIN u.transaction t where u.id=:id")
	public List<TransactionResponse> getTransactionByUser(@Param("id")Long id);


}
