package com.Intersoft.App.Exception;

public class UserNotFoundException extends RuntimeException{
	public UserNotFoundException(Long id) {
		super("Couldn't found the user with id:"+id);
	}
	public UserNotFoundException(String username,String mobile) {
		super("user with username "+username+" has registered with another mobile number");
	}
	public UserNotFoundException(String username,String password,int one) {
		super("Username and Password doesn't match");
	}
	public UserNotFoundException(String username) {
		super("Couldn't found the user with username:"+username);
	}
}
