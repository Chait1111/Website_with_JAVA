package com.Intersoft.App.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Intersoft.App.Dto.TransactionResponse;
import com.Intersoft.App.Entity.Transaction;
import com.Intersoft.App.Entity.User;
import com.Intersoft.App.Repository.TransactionRepository;
import com.Intersoft.App.Repository.UserRepository;
import com.Intersoft.App.Service.AppService;

@RestController
@CrossOrigin("http://localhost:3001/")
public class AppController {
	@Autowired
	AppService service;
	@PostMapping("/addUser")
	public User addUser(@RequestBody User user)
	{
		return service.addUserService(user);
	}
	@GetMapping("/getAllUsers")
	public List<User> getAllUsers()
	{
		return service.getAllUsers();
	}
	@GetMapping("/getUserById/{id}")
	public User getUserById(@PathVariable Long id)
	{
		return service.getUserById(id);
	}
	@PutMapping("/editUserById/{id}")
	public User editUserById(@PathVariable Long id,@RequestBody User user)
	{
		return service.editUserById(id,user);
	}
	@PutMapping("/forgetPassword/{Username}/{Mobile}/{newPass}")
	public User forgetPassword(@PathVariable String Username,@PathVariable String Mobile,@PathVariable String newPass)
	{
		return service.changePassword(Username,Mobile,newPass);
	}
	@GetMapping("/getUserByUsername/{username}")
	public User getByUsername(@PathVariable String username)
	{
		return service.getByUsername(username);
	}
	@DeleteMapping("/deleteUserById/{id}")
	public String deleteUserById(@PathVariable Long id)
	{
		return service.deleteUserById(id);
	}
	@GetMapping("/Login/{Username}/{Password}")
    public User Login(@PathVariable String Username,@PathVariable String Password) {
        return service.Login(Username,Password);
    }
	@Autowired
	UserRepository userRepository;
	@Autowired
	TransactionRepository transactionRepository;
	@PutMapping("/addTransaction/{id}")
    public User addTransaction(@PathVariable Long id,@RequestBody Transaction transaction){
    	User user = userRepository.findUserById(id);
    	user.getTransaction().add(transaction);
    	return userRepository.save(user);
    }
	@GetMapping("/getTransactionByUser/{id}")
    public List<TransactionResponse> getTransactionByUser(@PathVariable Long id){
        return userRepository.getTransactionByUser(id);	
    }
	@GetMapping("/getTransactionByTransactionId/{transactionId}")
    public Transaction getTransactionByTid(@PathVariable Long transactionId){
        return transactionRepository.getTransactionByTransactionId(transactionId);
    }
	@DeleteMapping("/deleteTransactionByTransactionId/{transactionId}")
    public String deleteTransactionByTid(@PathVariable Long transactionId){
		transactionRepository.deleteTransactionByTransactionId(transactionId);
        return "Transaction with TransactionId "+transactionId+" is cancelled";
    }
	@PutMapping("/editTransaction/{transactionId}")
    public Transaction editTransaction(@PathVariable Long transactionId,@RequestBody Transaction transactionobj){
    	Transaction transaction = transactionRepository.getTransactionByTransactionId(transactionId);
    	transaction.setAmount(transactionobj.getAmount());
    	transaction.setOperation(transactionobj.getOperation());
    	transaction.setDate(transactionobj.getDate());
    	return transactionRepository.save(transaction);
    }
}
