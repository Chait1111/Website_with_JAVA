package com.Intersoft.App.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Intersoft.App.Entity.Transaction;
@Repository
public interface TransactionRepository extends JpaRepository<Transaction,Long>{

	Transaction getTransactionByTransactionId(Long transactionId);

	@Transactional
	void deleteTransactionByTransactionId(Long transactionId);

}
