package com.Intersoft.App.Dto;

import com.Intersoft.App.Entity.User;

public class TransactionRequest {
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
}
