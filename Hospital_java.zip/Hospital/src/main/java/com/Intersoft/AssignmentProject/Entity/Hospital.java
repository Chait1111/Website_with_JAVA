package com.Intersoft.AssignmentProject.Entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="hospital_db")
public class Hospital {
	@Id
	@GeneratedValue
	private long id;
	@Column(nullable=false)
	private String patientName;
	@Column(nullable=false)
	private long phone_no;
	@Column(nullable=false)
	private String doctorName;
	@Column(nullable=false)
	private String gender;
	@Column(nullable=false)
	private int age;
	@Column(nullable=false)
	private String address;
	@Column(nullable=false)
	private String disease;
	@Column(nullable=false)
	private Boolean insurance;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable=false)
	private Date date;
	@PrePersist
	public void onCreate() {
		date = new Date();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public Boolean getInsurance() {
		return insurance;
	}
	public void setInsurance(Boolean insurance) {
		this.insurance = insurance;
	}
	public Hospital(long id, String patientName, long phone_no, String doctorName, Date date, String gender, int age,
			String address, String disease, Boolean insurance) {
		super();
		this.id = id;
		this.patientName = patientName;
		this.phone_no = phone_no;
		this.doctorName = doctorName;
		this.date = date;
		this.gender = gender;
		this.age = age;
		this.address = address;
		this.disease = disease;
		this.insurance = insurance;
	}
	public Hospital() {
		super();
	}
	
}
