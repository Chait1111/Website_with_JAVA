package com.Intersoft.AssignmentProject.Repository;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.Intersoft.AssignmentProject.Entity.Hospital;
@Repository
public interface ProjectRepository extends JpaRepository<Hospital,Long>{

	@Modifying
	@Query(value="insert into hospital_db(id,address,age,disease,doctor_name,gender,insurance,patient_name"
			+ ",phone_no,date) values(?9,?6,?5,?7,?3,?4,?8,?1,?2,?10)",nativeQuery = true)
	@Transactional
	void savePatient(String patientName, long phone_no, String doctorName, String gender,
			int age, String address,String disease, Boolean insurance, long id, Date date);
	
}
