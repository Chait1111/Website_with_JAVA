package com.Intersoft.AssignmentProject.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Intersoft.AssignmentProject.Entity.Hospital;
import com.Intersoft.AssignmentProject.Repository.ProjectRepository;

@Service
public class ProjectService {
	@Autowired
	ProjectRepository repository;

	public void addPatientCustom(Hospital patient) {
		long id = patient.getId();
		Date date = patient.getDate();
		String patientName = patient.getPatientName();
        long phone_no = patient.getPhone_no();
        String doctorName = patient.getDoctorName();
        String gender = patient.getGender();
        int age = patient.getAge();
        String address = patient.getAddress();
        String disease = patient.getDisease();
        Boolean insurance = patient.getInsurance();
		repository.savePatient(patientName,phone_no,doctorName,gender,age,address,disease,insurance,id,date);
	}

	public Hospital addPatient(Hospital patient) {
		return repository.save(patient);
	}
	
	public List<Hospital> getAllPatients() {
		return repository.findAll();
	}
	
	public Hospital getPatientById(long id) {
		return repository.findById(id).orElse(null);
	}

	public String deletePatientById(long id) {
		repository.deleteById(id);
		return "Record of patient by id "+id+" is deleted";
	}

	public Hospital editPatientById(long id, Hospital patient) {
		Hospital temp = repository.findById(id).orElse(null);
		temp.setAddress(patient.getAddress());
		temp.setAge(patient.getAge());
		temp.setDisease(patient.getDisease());
		temp.setDoctorName(patient.getDoctorName());
		temp.setGender(patient.getGender());
		temp.setInsurance(patient.getInsurance());
		temp.setPatientName(patient.getPatientName());
		temp.setPhone_no(patient.getPhone_no());
		temp.onCreate();
		return repository.save(temp);
	}
}
