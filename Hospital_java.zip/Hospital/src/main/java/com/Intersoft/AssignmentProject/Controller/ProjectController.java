package com.Intersoft.AssignmentProject.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Intersoft.AssignmentProject.Entity.Hospital;
import com.Intersoft.AssignmentProject.Service.ProjectService;

@RestController
@CrossOrigin("http://localhost:3001/")
public class ProjectController {
	@Autowired
	ProjectService service;
	
	@PostMapping("/addPatientCustom")
	public void addPatientCustom(@RequestBody Hospital patient) {
		service.addPatientCustom(patient);
	}
	
	@PostMapping("/addPatient")
	public Hospital addPatient(@RequestBody Hospital patient) {
		return service.addPatient(patient);
	}
	
	@GetMapping("/getAllPatients")
	public List<Hospital> getAllPatients() {
		return service.getAllPatients();
	}
	
	@GetMapping("/getPatientById/{id}")
	public Hospital getPatientById(@PathVariable long id) {
		return service.getPatientById(id);
	}
	
	@DeleteMapping("/deletePatientById/{id}")
	public String deletePatientById(@PathVariable long id) {
		return service.deletePatientById(id);
	}
	
	@PutMapping("/editPatientById/{id}")
	public Hospital editPatientById(@PathVariable long id,@RequestBody Hospital patient) {
		return service.editPatientById(id,patient);
	}
}