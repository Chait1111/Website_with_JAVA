import {BrowserRouter as Router , Routes , Route } from 'react-router-dom';
import "./App.css";
import Navbar from "./Components/Navbar";
import EmpDetails from "./Components/EmpDetails";
function App() {
  return (
    <div className="App">
      <Router>
        <Navbar/>
        <EmpDetails/>
      </Router>
    </div>
  );
}

export default App;
