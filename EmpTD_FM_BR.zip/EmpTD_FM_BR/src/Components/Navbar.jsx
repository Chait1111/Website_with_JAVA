import React from "react";

export default function Navbar() {
  return (
    <div className="container-fluid">
      <h3>Employee Restriction or Test Abilities</h3>
    </div>
  );
}
