import React, { useEffect, useState } from "react";
import axios from "axios";
export default function TestDetails() {
  const [test, setTest] = useState([]); //list of test
  const [tRest , setTRest] = useState([]); //selected test
  const [restype, setRestype] = useState([]); //list of restrictions
  const [temp , setTemp] = useState([]); //selected restriction
  useEffect(() => {
    loadTest();
  }, []);
  useEffect(() => {
    loadRestrictions();
  }, []);
  const loadRestrictions = async () => {
    const result = await axios.get(
      "http://localhost:8080/getRestrictionTypeList"
    );
    setRestype(result.data);
  };
  const loadTest = async () => {
    const result = await axios.get("http://localhost:8080/getTestTypeList");
    setTest(result.data);
  };
  return (
    <div>
      <div className="row">
        <div className="col">Test Date/Time:</div>
        <div className="col">
          <input type="date" id="test_date" name="test_date" />
        </div>
        <div className="col">
          <input type="time" id="test_time" name="test_time" />
        </div>
      </div>
      <div className="row">
        <div className="col">Test Type:</div>
        <div className="col">
          {test.map((t, index) => (
            <div className="form-check form-check-inline col">
              <input
                className="form-check-input"
                type="radio"
                name="test_type"
                id={index}
                onClick={()=>setTRest(t.test_type)}
              />
              <label className="form-check-label" htmlFor={index}>
                {t.test_type}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div className="row">
        <div className="col">Employee Work shift:</div>
        <input
          className="col"
          type="number"
          id="work_hrs"
          name="work_hrs"
          min="1"
          max="24"
        ></input>
        <div className="col">Hrs/Day</div>
        <input
          className="col"
          type="number"
          id="restrict_hrs"
          name="restrict_hrs"
          min="1"
          max="168"
        ></input>
        <div className="col">Hrs/Week</div>
      </div>
      <div className="row">
        <div className="col">Restricted Hours:</div>
        <input
          className="col"
          type="number"
          id="work_hrs"
          name="work_hrs"
          min="1"
          max="24"
        ></input>
        <div className="col">Hrs/Day</div>
        <input
          className="col"
          type="number"
          id="restrict_hrs"
          name="restrict_hrs"
          min="1"
          max="168"
        ></input>
        <div className="col">Hrs/Week</div>
      </div>
      {tRest === "Restriction" ? <div className="row">
      <div className="col">Restriction Type: </div>
      <div className="col-2">
        {restype.map((r, index) => (
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name="restriction_type"
              id={index}
              onClick={()=>setTemp(r.restriction_type)}
            />
            <label className="form-check-label" htmlFor={index}>
              {r.restriction_type}
            </label>
          </div>
        ))}
      </div>
      {temp === "Temporary" ? <div className="col-6">
        <h6 className="">End Date:</h6>
        <input type="date" id="end_date" name="end_date" />
      </div> : ""}
    </div> : ""}
    </div>
  );
}
