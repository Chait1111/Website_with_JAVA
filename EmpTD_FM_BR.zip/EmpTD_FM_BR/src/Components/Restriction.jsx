import React, { useEffect, useState } from "react";
import axios from "axios";
export default function Restriction() {
  const [restype, setRestype] = useState([]); //list of restrictions
  const [temp , setTemp] = useState([]); //selected restriction
  useEffect(() => {
    loadRestrictions();
  }, []);
  const loadRestrictions = async () => {
    const result = await axios.get(
      "http://localhost:8080/getRestrictionTypeList"
    );
    setRestype(result.data);
  };
  return (
    <div className="row">
      <div className="col">Restriction Type: </div>
      <div className="col-2">
        {restype.map((r, index) => (
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name="restriction_type"
              id={index}
              onClick={()=>setTemp(r.restriction_type)}
            />
            <label className="form-check-label" htmlFor={index}>
              {r.restriction_type}
            </label>
          </div>
        ))}
      </div>
      {temp === "Temporary" ? <div className="col-6">
        <h6 className="">End Date:</h6>
        <input type="date" id="end_date" name="end_date" />
      </div> : ""}
    </div>
  );
}
