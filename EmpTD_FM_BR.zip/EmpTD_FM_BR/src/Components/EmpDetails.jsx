import React, { useEffect, useState } from "react";
import axios from "axios";
import "../App.css";
export default function EmpDetails() {
  const [emp, setEmp] = useState([]); //list of employee
  const [restrict, setRestrict] = useState([]); //list of restriction by employee
  const [employee, setEmployee] = useState({
    firstName: "select",
    lastName: "employee",
  }); //selected employee
  const [modify, setModify] = useState(false); //if restriction is selected or not to modify it
  const [rest, setRest] = useState({emp_test_id:"select restriction",test_date:"",test_time:"",test_type_id:{test_type:""},restriction_id:{restriction_type:""}}); //selected restriction to modify
  const [mrest, setMRest] = useState([]); //selected restriction ID to modify
  const [test, setTest] = useState([]); //list of test
  const [tRest, setTRest] = useState([]); //selected test
  const [testid, setTestID] = useState([]); //selected test's ID
  const [restype, setRestype] = useState([]); //list of restrictions
  const [temp, setTemp] = useState([]); //selected restriction
  const [restid, setRestID] = useState(); //selected restriction's ID
  const [orderBy, setOrderBy] = useState(true); //Order By firstName or lastName
  const [select_test, setSelectTest] = useState([]); //modify Selected test type
  const [tomorrow, setTomorrow] = useState([]); //tomorrow's date
  const [select_restriction, setSelectRestriction] = useState([]); //modify Selected restriction type
  const [newtd, setNewTD] = useState({
    test_shift_hrs_day: "",
    test_shift_hrs_week: "",
    test_restricted_hrs_day: "",
    test_restricted_hrs_week: "",
    test_date: "",
    test_time: "",
    restriction_end_date: "",
    date_entered: "",
    date_modified: "",
  }); //new test demand
  const [reset, setReset] = useState({
    test_shift_hrs_day: "",
    test_shift_hrs_week: "",
    test_restricted_hrs_day: "",
    test_restricted_hrs_week: "",
    test_date: "",
    test_time: "",
    restriction_end_date: "",
    date_entered: "",
    date_modified: "",
  }); //new test demand
  const {
    test_type_id,
    test_id,
    test_rest_id,
    rest_id,
    test_type,
    restriction_id,
    restriction_type,
    employee_id,
    emp_id,
    firstName,
    lastName,
    is_deleted,
    test_shift_hrs_day,
    test_shift_hrs_week,
    test_restricted_hrs_day,
    test_restricted_hrs_week,
    test_date,
    test_time,
    restriction_end_date,
    date_entered,
    date_modified,
  } = newtd;
  useEffect(() => {
    loadTest();
  }, []);
  useEffect(() => {
    loadRestrictions();
  }, []);
  const loadRestrictions = async () => {
    const result = await axios.get(
      "http://localhost:8080/getRestrictionTypeList"
    );
    setRestype(result.data);
  };
  const loadTest = async () => {
    const result = await axios.get("http://localhost:8080/getTestTypeList");
    setTest(result.data);
  };
  useEffect(() => {
    loadEmp();
  }, []);
  const loadEmp = async () => {
    const result = await axios.get(
      "http://localhost:8080/getEmployeeListByFirstName"
    );
    setEmp(result.data);
  };
  const loadEmpFirst = async () => {
    setOrderBy(true);
    const result = await axios.get(
      "http://localhost:8080/getEmployeeListByFirstName"
    );
    setEmp(result.data);
  };
  const loadEmpLast = async () => {
    setOrderBy(false);
    const result = await axios.get(
      "http://localhost:8080/getEmployeeListByLastName"
    );
    setEmp(result.data);
  };
  const loadRestrict = async () => {
    const result = await axios.get(
      `http://localhost:8080/getEmployeeTestDemandByEmployee/${employee.emp_id}`
    );
    setRestrict(result.data);
  };
  const ModifyDemand = async (r) => {
    setModify(true);
    setRest(r);
    setNewTD(r);
    setMRest(r.emp_test_id);
    loadTestDetails(r.emp_test_id);
    setSelectTest(r.test_type_id.test_id);
    selectTestType(r.test_type_id);
    selectRestType(r.restriction_id);
    setRestID(r.restriction_id.rest_id);
    if (r.test_type_id.test_type === "Physical Ability") {
      setTRest("Physical Ability");
      setSelectRestriction();
      setTemp();
    } else {
      setSelectRestriction(r.restriction_id.rest_id);
    }
    console.log(rest);
    console.log(select_test, select_restriction);
  };
  const ChangeEmp = (e) => {
    setEmployee(e);
    setModify(false);
    loadRestrict();
    setNewTD(reset);
    setTestID([]);
    setTRest([]);
    setRestID([]);
    setSelectTest([]);
    setRest({emp_test_id:"select restriction",test_date:"",test_time:"",test_type_id:{test_type:""},restriction_id:{restriction_type:""}});
    setSelectRestriction([]);
    let today = new Date().toISOString().slice(0, 10);
    let next = new Date().getDate() + 1;
    today = today.slice(0, -2);
    if(next<10){
      today +="0"+next;
    }else{
      today += next;
    }
    setTomorrow(today);
    console.log(tomorrow);
  };
  const ResetAll = () => {
    setModify(false);
    loadRestrict();
    setNewTD(reset);
    setTestID([]);
    setTRest([]);
    setRestID([]);
    setSelectTest([]);
    setSelectRestriction([]);
  };
  const onInputChange = (e) => {
    setNewTD({ ...newtd, [e.target.name]: e.target.value });
    console.log(newtd);
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    console.log(e);
    // setFormErrors(validation(newtd));
    if (modify === false) {
      console.log(employee, "  ", testid, "  ", restid);
      await axios.post(
        `http://localhost:8080/addEmployeeTestDemand/${employee.emp_id}/${testid}/${restid}`, 
        newtd
      );
      alert(`Employee with id ${employee.emp_id} added new Test Demand`);
    } else {
      console.log(mrest, "  ", testid, "  ", restid);
      await axios.put(
        `http://localhost:8080/modifyEmployeeTestDemand/${mrest}/${testid}/${restid}`,
        newtd
      );
      alert(`Test Demand with id ${mrest} is modified`);
    }
    loadRestrict();
    ResetAll();
    setRest({emp_test_id:"select restriction",test_date:"",test_time:"",test_type_id:{test_type:""},restriction_id:{restriction_type:""}});
  };
  const deletetest = async (id) => {
    console.log(rest);
    const result = await axios.put(
      `http://localhost:8080/deleteEmployeeTestDemandByEmployeeTestId/${id}`
    );
    loadRestrict();
    ResetAll();
  };
  const selectTestType = async (t) => {
    setTRest(t.test_type);
    setSelectTest(t.test_id);
    setTestID(t.test_id);
    if (t.test_type === "Physical Ability") {
      console.log("physical ability");
      newtd.restriction_end_date = "";
      setNewTD({ ...newtd });
      setRestID("");
      setSelectRestriction([]);
    }
  };
  const selectRestType = async (r) => {
    setRestID(r.rest_id);
    setSelectRestriction(r.rest_id);
    setTemp(r.restriction_type);
    if (r.restriction_type !== "Temporary") {
      console.log("Not Temporary");
      newtd.restriction_end_date = "";
      setNewTD({ ...newtd });
    }
  };
  const loadTestDetails = async (id) => {
    const result = await axios.get(
      `http://localhost:8080/getEmployeeTestDemandByEmployeeTestId/${id}`
    );
    setNewTD(result.data);
  };
  return (
    <div className="container">
      <form onSubmit={(e) => onSubmit(e)}>
        <div className="row mt-3">
          <div className="col-3">Employee Name</div>
          <div className="dropdown col-2">
            <button
              className="btn btn-light dropdown-toggle"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              {employee.firstName} {employee.lastName}
            </button>
            <ul className="dropdown-menu">
              {emp.map((e, index) =>
                e.is_deleted === false ? (
                  <li key={index}>
                    <a className="dropdown-item" onClick={() => ChangeEmp(e)}>
                      {e.firstName} {e.lastName}
                    </a>
                  </li>
                ) : (
                  ""
                )
              )}
            </ul>
          </div>
          <h6 className="col-2">Order By </h6>
          <div className="form-check form-check-inline col-2">
            <input
              className="form-check-input"
              type="radio"
              name="order"
              id="order"
              checked={orderBy === true}
              onClick={() => loadEmpFirst()}
            />
            <label className="form-check-label" htmlFor="order">
              First Name
            </label>
          </div>
          <div className="form-check form-check-inline col-2">
            <input
              className="form-check-input"
              type="radio"
              name="order"
              id="order"
              checked={orderBy === false}
              onClick={() => loadEmpLast()}
            />
            <label className="form-check-label" htmlFor="order">
              Last Name
            </label>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-3">Restrictions/Abilities Date</div>
          <div className="dropdown col-2">
            <button
              className="btn btn-light dropdown-toggle"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
              onClick={() => loadRestrict()}
            >
              {rest.emp_test_id} {rest.test_date} {rest.test_time}
              {"  "}
              {rest.test_type_id.test_type === "Physical Ability"
                ? rest.test_type_id.test_type
                : rest.restriction_id.restriction_type}
            </button>
            <ul className="dropdown-menu">
              {restrict.map((r, index) => (
                <li key={index}>
                  {r.is_deleted === true ? (
                    " "
                  ) : (
                    <a
                      className="dropdown-item"
                      onClick={() => ModifyDemand(r)}
                    >
                      {r.emp_test_id} {r.test_date} {r.test_time}
                      {"  "}
                      {r.test_type_id.test_type === "Physical Ability"
                        ? r.test_type_id.test_type
                        : r.restriction_id.restriction_type}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>
          <div className="col"></div>
          <div className="col"></div>
          <div className="col"></div>
        </div>
        {modify === true ? (
          <div>
            <div className="row">
              <div className="col-3">Date Entered:</div>
              <span className="col-2">{rest.date_entered}</span>
              <div className="col-3"></div>
            </div>
            <div className="row">
              <div className="col-3">Date Modified:</div>
              <span className="col-2">{rest.date_modified}</span>
              <div className="col-3"></div>
            </div>
          </div>
        ) : (
          ""
        )}
        <div>
          <div className="row mt-3">
            <hr />
            <div className="col-3">Test Date/Time:</div>

            <div className="col-2">
              <input
                type="date"
                id="test_date"
                name="test_date"
                min={tomorrow}
                max="2023-12-31"
                value={test_date}
                required
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="col-2">
              <input
                type="time"
                id="test_time"
                name="test_time"
                value={test_time}
                required
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="col-2">HH:MM</div>
            <div className="col-3"></div>
          </div>
          <div className="row">
            <div className="col-3">Test Type:</div>
            {test.map((t, index) => t.is_deleted === false ? (
              <div className="form-check form-check-inline col-3">
                <input
                  className="form-check-input"
                  type="radio"
                  name="test_type"
                  id={t.test_id}
                  checked={select_test === t.test_id}
                  required
                  onClick={() => selectTestType(t)}
                />
                <label className="form-check-label" htmlFor={index}>
                  {t.test_type}
                </label>
              </div>
            ) : "")}
            <div className="col"></div>
            <div className="col"></div>
          </div>
          <div className="row">
            <div className="col-3"></div>
            <div className="col-3">Employee Work shift:</div>
            <input
              className="col"
              type="number"
              id="test_shift_hrs_day"
              name="test_shift_hrs_day"
              min="0"
              max="24"
              required
              value={test_shift_hrs_day}
              onChange={(e) => onInputChange(e)}
            ></input>
            <div className="col">Hrs/Day</div>
            <input
              className="col"
              type="number"
              id="test_shift_hrs_week"
              name="test_shift_hrs_week"
              min="0"
              max="168"
              value={test_shift_hrs_week}
              required
              onChange={(e) => onInputChange(e)}
            ></input>
            <div className="col">Hrs/Week</div>
          </div>
          <div className="row">
            <div className="col-3"></div>
            <div className="col-3">Restricted Hours:</div>
            <input
              className="col"
              type="number"
              id="test_restricted_hrs_day"
              name="test_restricted_hrs_day"
              min="0"
              max={24 - test_shift_hrs_day}
              value={test_restricted_hrs_day}
              onChange={(e) => onInputChange(e)}
              required
            ></input>
            <div className="col">Hrs/Day</div>
            <input
              className="col"
              type="number"
              id="test_restricted_hrs_week"
              name="test_restricted_hrs_week"
              min="0"
              max={168 - test_shift_hrs_week}
              required
              value={test_restricted_hrs_week}
              onChange={(e) => onInputChange(e)}
            ></input>
            <div className="col">Hrs/Week</div>
          </div>
          {tRest === "Restriction" ? (
            <div className="row mt-4">
              <hr />
              <div className="col-3">Restriction Type: </div>
              <div className="col-1">
                {restype.map((r, index) => (
                  <div className="form-check form-check-inline">
                    <input
                      className="form-check-input"
                      type="radio"
                      name="restriction_type"
                      id={r.restriction_id}
                      checked={select_restriction === r.rest_id}
                      required
                      onClick={() => selectRestType(r)}
                    />
                    <label className="form-check-label" htmlFor={index}>
                      {r.restriction_type}
                    </label>
                  </div>
                ))}
              </div>
              <div className="col"></div>
              {temp === "Temporary" ? (
                <div className="col-6">
                  <h6 className="">End Date:</h6>
                  <input
                    type="date"
                    id="restriction_end_date"
                    name="restriction_end_date"
                    required
                    min={tomorrow}
                    value={restriction_end_date}
                    onChange={(e) => onInputChange(e)}
                  />
                </div>
              ) : (
                <div className="col-6"></div>
              )}
              <div className="col"></div>
            </div>
          ) : (
            ""
          )}
        </div>
        <hr />
        {modify === true ? (
          <div className="container-fluid">
            <button type="submit" className="btn btn-secondary text-dark mx-2">
              Modify
            </button>
            <button
              className="btn btn-secondary text-dark mx-2"
              onClick={() => ResetAll()}
            >
              Reset
            </button>
            <button
              className="btn btn-secondary text-dark mx-2"
              onClick={() => deletetest(rest.emp_test_id)}
            >
              Remove
            </button>
          </div>
        ) : (
          <div className="container-fluid">
            <button type="submit" className="btn btn-secondary text-dark mx-2">
              save
            </button>
            <button
              className="btn btn-secondary text-dark mx-2"
              onClick={() => ResetAll()}
            >
              Reset
            </button>
            <button className="btn btn-secondary text-dark mx-2" disabled>
              Remove
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
