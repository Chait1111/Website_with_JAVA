import React, { useEffect, useState } from "react";
import axios from "axios";
export default function EmpRest() {
  const [restrict, setRestrict] = useState([]);
//   useEffect(() => {
//     loadRestrict();
//   }, []);
  const loadRestrict = async () => {
    const result = await axios.get(
      "http://localhost:8080/getEmployeeTestDemandByEmployee/40"
    );
    setRestrict(result.data);
  };
  return (
    <div>
      <div className="col">Restrictions/Abilities Date</div>
      <button onClick={()=>loadRestrict()}>Load</button>
      <div className="dropdown col">
          <button
            className="btn btn-secondary dropdown-toggle"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Restrictions
          </button>
          <ul className="dropdown-menu">
            {restrict.map((r, index) => (
              <li key={index}>
                <a className="dropdown-item" href="#">
                  {r.emp_test_id}
                </a>
              </li>
            ))}
          </ul>
        </div>
    </div>
  );
}
