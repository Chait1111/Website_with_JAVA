import React from 'react'
import { Link } from "react-router-dom";
export default function Buttons() {
  return (
    <div className="container-fluid">
      <Link className="btn btn-outline-light mx-2" to="/addUser">Save</Link>
      <Link className="btn btn-outline-light mx-2" to="/addUser">Reset</Link>
      <Link className="btn btn-outline-light mx-2" to="/addUser">Remove</Link>
    </div>
  )
}
