package com.Intersoft.RelateExe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelateExeApplicationTests {

	@Test
	void contextLoads() {
	}

}
