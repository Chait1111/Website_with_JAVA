package com.Intersoft.RelateExe.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Intersoft.RelateExe.Entity.Model;

@Repository
public interface ModelRepository extends JpaRepository<Model,Integer>{

}
