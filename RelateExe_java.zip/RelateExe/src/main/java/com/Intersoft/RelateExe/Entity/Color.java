package com.Intersoft.RelateExe.Entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Color {
	@Id
	@GeneratedValue
	private int color_id;
	private String name;
	private String code;
	@JsonIgnore
	@OneToMany(mappedBy = "color_id")
	private Set<Inventory> inventory;
	public int getColor_id() {
		return color_id;
	}
	public void setColor_id(int color_id) {
		this.color_id = color_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Color(int color_id, String name, String code) {
		super();
		this.color_id = color_id;
		this.name = name;
		this.code = code;
	}
	public Color() {
		super();
	}
}
