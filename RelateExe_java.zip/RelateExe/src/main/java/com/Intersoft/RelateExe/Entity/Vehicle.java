package com.Intersoft.RelateExe.Entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Vehicle {
	@Id
	@GeneratedValue
	private int vehicle_id;
	private String owner_name;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="manufacture_id",referencedColumnName="manufacture_id")
	private Manufacturer manufacture_id;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="model_id",referencedColumnName="model_id")
	private Model model_id;
	@JsonIgnore
	@OneToOne(mappedBy = "vehicle_id")
	private Inventory inventory;
	@ManyToMany
	@JoinTable(
			name = "vehicle_incentive" , 
	        joinColumns = @JoinColumn(name="vehicle_id") , 
			inverseJoinColumns = @JoinColumn(name = "incentive_id"))
	public Set<Incentive> incentives;
	
	
	public Vehicle(int vehicle_id, String owner_name, Manufacturer manufacture_id, Model model_id, Inventory inventory,
			Set<Incentive> incentives) {
		super();
		this.vehicle_id = vehicle_id;
		this.owner_name = owner_name;
		this.manufacture_id = manufacture_id;
		this.model_id = model_id;
		this.inventory = inventory;
		this.incentives = incentives;
	}
	public Vehicle() {
		super();
	}
	public int getVehicle_id() {
		return vehicle_id;
	}
	public void setVehicle_id(int vehicle_id) {
		this.vehicle_id = vehicle_id;
	}
	public Manufacturer getManufacture_id() {
		return manufacture_id;
	}
	public void setManufacture_id(Manufacturer manufacture_id) {
		this.manufacture_id = manufacture_id;
	}
	public Model getModel_id() {
		return model_id;
	}
	public void setModel_id(Model model_id) {
		this.model_id = model_id;
	}
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public Set<Incentive> getIncentives() {
		return incentives;
	}
	public void setIncentives(Set<Incentive> incentives) {
		this.incentives = incentives;
	}
}
