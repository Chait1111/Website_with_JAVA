package com.Intersoft.RelateExe.Entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Incentive {
	@Id
	@GeneratedValue
	private int incentive_id;
	private String type;
	private double amount;
	@JsonIgnore
	@ManyToMany(mappedBy = "incentives")
	private Set<Vehicle> vehicles;
	public int getIncentive_id() {
		return incentive_id;
	}
	public void setIncentive_id(int incentive_id) {
		this.incentive_id = incentive_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Set<Vehicle> getVehicles() {
		return vehicles;
	}
	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	
	public Incentive(int incentive_id, String type, double amount, Set<Vehicle> vehicles) {
		super();
		this.incentive_id = incentive_id;
		this.type = type;
		this.amount = amount;
		this.vehicles = vehicles;
	}
	public Incentive() {
		super();
	}
}
