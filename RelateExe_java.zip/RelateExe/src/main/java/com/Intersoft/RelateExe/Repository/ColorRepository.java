package com.Intersoft.RelateExe.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Intersoft.RelateExe.Entity.Color;

@Repository
public interface ColorRepository extends JpaRepository<Color,Integer>{

}
