package com.Intersoft.RelateExe.Entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Manufacturer {
	@Id
	@GeneratedValue
	private int manufacture_id;
	private String manufacture_name;
	private String country;
	@JsonIgnore
	@OneToMany(mappedBy="manufacture_id")
	private Set<Vehicle> vehicles;
	public int getManufacture_id() {
		return manufacture_id;
	}
	public void setManufacture_id(int manufacture_id) {
		this.manufacture_id = manufacture_id;
	}
	public String getManufacture_name() {
		return manufacture_name;
	}
	public void setManufacture_name(String manufacture_name) {
		this.manufacture_name = manufacture_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Set<Vehicle> getVehicles() {
		return vehicles;
	}
	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	
	public Manufacturer(int manufacture_id, String manufacture_name, String country, Set<Vehicle> vehicles) {
		super();
		this.manufacture_id = manufacture_id;
		this.manufacture_name = manufacture_name;
		this.country = country;
		this.vehicles = vehicles;
	}
	public Manufacturer() {
		super();
	}
	
}
