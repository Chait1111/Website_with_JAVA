package com.Intersoft.RelateExe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelateExeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelateExeApplication.class, args);
	}

}
