package com.Intersoft.RelateExe.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Intersoft.RelateExe.Entity.Color;
import com.Intersoft.RelateExe.Entity.Incentive;
import com.Intersoft.RelateExe.Entity.Inventory;
import com.Intersoft.RelateExe.Entity.Manufacturer;
import com.Intersoft.RelateExe.Entity.Model;
import com.Intersoft.RelateExe.Entity.Vehicle;
import com.Intersoft.RelateExe.Repository.ColorRepository;
import com.Intersoft.RelateExe.Repository.IncentiveRepository;
import com.Intersoft.RelateExe.Repository.InventoryRepository;
import com.Intersoft.RelateExe.Repository.ManufacturerRepository;
import com.Intersoft.RelateExe.Repository.ModelRepository;
import com.Intersoft.RelateExe.Repository.VehicleRepository;

@Service
public class RelateService {

	@Autowired
	ModelRepository modelRepository;
	
	@Autowired
	ManufacturerRepository mfRepository;
	
	@Autowired
	ColorRepository colorRepository;
	
	@Autowired
	IncentiveRepository incentiveRepository;
	
	@Autowired
	VehicleRepository vehicleRepository;
	
	@Autowired
	InventoryRepository inventoryRepository;
	
	public Model addModel(Model model) {
		return modelRepository.save(model);
	}

	public List<Model> listModels() {
		return modelRepository.findAll();
	}

	public Manufacturer addManufacturer(Manufacturer manufacturer) {
		return mfRepository.save(manufacturer);
	}

	public List<Manufacturer> listManufacturers() {
		return mfRepository.findAll();
	}

	public Color addColor(Color color) {
		return colorRepository.save(color);
	}

	public List<Color> listColors() {
		return colorRepository.findAll();
	}

	public Incentive addIncentive(Incentive incentive) {
		return incentiveRepository.save(incentive);
	}

	public List<Incentive> listIncentives() {
		return incentiveRepository.findAll();
	}

	public List<Vehicle> listVehicles() {
		return vehicleRepository.findAll();
	}

	public Vehicle addVehicle(int manufacture_id, int model_id, Vehicle vehicle) {
		Manufacturer manufacturer = mfRepository.findById(manufacture_id).get();
		Model model = modelRepository.findById(model_id).get();
		vehicle.setManufacture_id(manufacturer);
		vehicle.setModel_id(model);
		return vehicleRepository.save(vehicle);
	}

	public Inventory addInventory(Inventory inventory, int vehicle_id, int color_id) {
		Vehicle vehicle = vehicleRepository.findById(vehicle_id).get();
		Color color = colorRepository.findById(color_id).get();
		inventory.setVehicle_id(vehicle);
		inventory.setColor_id(color);
		return inventoryRepository.save(inventory);
	}
	
	public List<Inventory> listInventorys() {
		return inventoryRepository.findAll();
	}

	public Vehicle vehicleIncentives(int vehicle_id, int incentive_id) {
		Vehicle vehicle = vehicleRepository.findById(vehicle_id).get();
		Incentive incentive = incentiveRepository.findById(incentive_id).get();
		vehicle.incentives.add(incentive);
		return vehicleRepository.save(vehicle);
	}

	public Optional<Vehicle> getVehicleById(int vehicle_id) {
		return vehicleRepository.findById(vehicle_id);
	}

}
