package com.Intersoft.RelateExe.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Intersoft.RelateExe.Entity.Color;
import com.Intersoft.RelateExe.Entity.Incentive;
import com.Intersoft.RelateExe.Entity.Inventory;
import com.Intersoft.RelateExe.Entity.Manufacturer;
import com.Intersoft.RelateExe.Entity.Model;
import com.Intersoft.RelateExe.Entity.Vehicle;
import com.Intersoft.RelateExe.Service.RelateService;

@RestController
public class RelateController {
	@Autowired
	RelateService service;
	
	@PostMapping("/addModel")
	private Model addModel(@RequestBody Model model) {
		return service.addModel(model);
	}
	
	@GetMapping("/listModels")
	private List<Model> listModels() {
		return service.listModels();
	}
	
	@PostMapping("/addManufacturer")
	private Manufacturer addManufacturer(@RequestBody Manufacturer manufacturer) {
		return service.addManufacturer(manufacturer);
	}
	
	@GetMapping("/listManufacturers")
	private List<Manufacturer> listManufacturers() {
		return service.listManufacturers();
	}
	
	@PostMapping("/addColor")
	private Color addColor(@RequestBody Color color) {
		return service.addColor(color);
	}
	
	@GetMapping("/listColors")
	private List<Color> listColors() {
		return service.listColors();
	}
	
	@PostMapping("/addIncentive")
	private Incentive addIncentive(@RequestBody Incentive incentive) {
		return service.addIncentive(incentive);
	}
	
	@GetMapping("/listIncentives")
	private List<Incentive> listIncentives() {
		return service.listIncentives();
	}
	
	@PostMapping("/addVehicle/manufacturer/{manufacture_id}/model/{model_id}")
	private Vehicle addVehicle(@RequestBody Vehicle vehicle,@PathVariable int manufacture_id, @PathVariable int model_id) {
		return service.addVehicle(manufacture_id,model_id,vehicle);
	}
	
	@GetMapping("/listVehicles")
	private List<Vehicle> listVehicles() {
		return service.listVehicles();
	}
	
	@PostMapping("/addInventory/vehicle/{vehicle_id}/color/{color_id}")
	private Inventory addInventory(@RequestBody Inventory inventory,@PathVariable int vehicle_id, @PathVariable int color_id) {
		return service.addInventory(inventory,vehicle_id,color_id);
	}
	
	@GetMapping("/listInventorys")
	private List<Inventory> listInventorys() {
		return service.listInventorys();
	}
	
	@PutMapping("/Vehicle/{vehicle_id}/Incentive/{incentive_id}")
	private Vehicle vehicleIncentives(@PathVariable int vehicle_id,@PathVariable int incentive_id) {
		return service.vehicleIncentives(vehicle_id,incentive_id);
	}
	
	@GetMapping("/Vehicle/{vehicle_id}")
	private Optional<Vehicle> getVehicleById(@PathVariable int vehicle_id) {
		return service.getVehicleById(vehicle_id);
	}
	
}
