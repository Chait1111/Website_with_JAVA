package com.Intersoft.RelateExe.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Inventory {
	@Id
	@GeneratedValue
	private int inventory_id;
	private double price;
	@OneToOne
	@JoinColumn(name = "vehicle_id", referencedColumnName = "vehicle_id")
	private Vehicle vehicle_id;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "color_id", referencedColumnName = "color_id")
	private Color color_id;
	public int getInventory_id() {
		return inventory_id;
	}
	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Vehicle getVehicle_id() {
		return vehicle_id;
	}
	public void setVehicle_id(Vehicle vehicle_id) {
		this.vehicle_id = vehicle_id;
	}
	public Color getColor_id() {
		return color_id;
	}
	public void setColor_id(Color color_id) {
		this.color_id = color_id;
	}
	public Inventory(int inventory_id, double price, Vehicle vehicle_id, Color color_id) {
		super();
		this.inventory_id = inventory_id;
		this.price = price;
		this.vehicle_id = vehicle_id;
		this.color_id = color_id;
	}
	public Inventory() {
		super();
	}
}
