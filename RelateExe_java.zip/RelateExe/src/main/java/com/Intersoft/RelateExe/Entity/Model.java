package com.Intersoft.RelateExe.Entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Model {
	@Id
	@GeneratedValue
	private int model_id;
	private String model_name;
	private int production_year;
	@JsonIgnore
	@OneToMany(mappedBy="model_id")
	private Set<Vehicle> vehicles;
	public int getModel_id() {
		return model_id;
	}
	public void setModel_id(int model_id) {
		this.model_id = model_id;
	}
	public String getModel_name() {
		return model_name;
	}
	public void setModel_name(String model_name) {
		this.model_name = model_name;
	}
	public Set<Vehicle> getVehicles() {
		return vehicles;
	}
	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	public int getProduction_year() {
		return production_year;
	}
	public void setProduction_year(int production_year) {
		this.production_year = production_year;
	}
	public Model(int model_id, String model_name, int production_year, Set<Vehicle> vehicles) {
		super();
		this.model_id = model_id;
		this.model_name = model_name;
		this.production_year = production_year;
		this.vehicles = vehicles;
	}
	public Model() {
		super();
	}
}
